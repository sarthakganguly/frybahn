/** @format */

let Colors = {
	white: new Color(1, 1, 1),
	grey: new Color(0.5, 0.5, 0.5),
	black: new Color(0, 0, 0),
};
