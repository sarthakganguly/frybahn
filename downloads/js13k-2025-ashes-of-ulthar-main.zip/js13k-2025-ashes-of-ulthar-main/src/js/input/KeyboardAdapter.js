// KeyboardAdapter

import { Input } from './Input';
import { game } from '../Game';
import { Audio } from '../Audio';

export const KeyboardAdapter = {
    init() {
        KeyboardAdapter.held = [];

        window.addEventListener('keydown', event => {
            //let k = KeyboardAdapter.map[event.code];
            // Uncomment to debug key presses
            // console.log(event.key, event.keyCode, event.code, k);

            // Hack to ensure we initialize audio after user interacts with game
            Audio.initContext();

            //if (Input.Action.includes(event.code)) {
            //if (k) {
            //    KeyboardAdapter.held[k] = true;
              KeyboardAdapter.held[event.code] = true;
            //}
        });

        window.addEventListener('keyup', event => {
            //let k = KeyboardAdapter.map[event.code];
            //if (k) {
            //    KeyboardAdapter.held[k] = false;
            //}
            KeyboardAdapter.held[event.code] = false;

            /*if (event.key >= '1' && event.key <= '9') {
                game.nextLevel = Number(event.key) - 1;
                game.screens.pop();
            }*/
        });

        KeyboardAdapter.reset();
    },

    //update() {
        // For keyboards, we want to convert the state of the various arrow keys being held down
        // into a directional vector. We use the browser's event to handle the held state of
        // the other action buttons, so we don't need to process them here.
        /*let state =
            (KeyboardAdapter.held[Input.Action.UP] ? 1 : 0) +
            (KeyboardAdapter.held[Input.Action.DOWN] ? 2 : 0) +
            (KeyboardAdapter.held[Input.Action.LEFT] ? 4 : 0) +
            (KeyboardAdapter.held[Input.Action.RIGHT] ? 8 : 0);*/

        //KeyboardAdapter.direction = KeyboardAdapter.arrowDirections[state];
    //},

    reset() {
        //KeyboardAdapter.direction = 0;
        for (let action of Input.Action) {
            KeyboardAdapter.held[action] = false;
        }
        //KeyboardAdapter.held = [];
        //KeyboardAdapter.held.length = 0;
    }
};
