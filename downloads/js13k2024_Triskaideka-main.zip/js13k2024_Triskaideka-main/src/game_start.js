getDelta();
gameLoop();

loadGameMenu();
//loadGameAction();