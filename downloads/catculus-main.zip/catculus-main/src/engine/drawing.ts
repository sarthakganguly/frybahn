import { Vector } from './vector';

export const drawCircle = (ctx: CanvasRenderingContext2D, pos: Vector, radius: number, color?: string, stroke?: string): void => {
    drawEllipse(ctx, pos, radius, radius, color, stroke);
};

export const drawEllipse = (ctx: CanvasRenderingContext2D, pos: Vector, x: number, y: number, color?: string, stroke?: string): void => {
    ctx.beginPath();
    if (color) ctx.fillStyle = color;
    ctx.ellipse(pos.x, pos.y, x, y, 0, 0, Math.PI * 2);
    ctx.fill();
    if (stroke) {
        ctx.strokeStyle = stroke;
        ctx.stroke();
    }
};

export const fillRect = (ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number): void => {
    ctx.fillRect(x - w * 0.5, y - h * 0.5, w, h);
};

export const drawRect = (ctx: CanvasRenderingContext2D, pos: Vector, size: Vector, fill: string, stroke: string): void => {
    ctx.beginPath();
    ctx.fillStyle = fill;
    ctx.strokeStyle = stroke;
    ctx.rect(pos.x - size.x * 0.5, pos.y - size.y * 0.5, size.x, size.y);
    if (fill) ctx.fill();
    if (stroke) ctx.stroke();
    ctx.fill();
};

export const roundRect = (ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number): void => {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
};

export const drawColoredText = (ctx: CanvasRenderingContext2D, content: string, x: number, y: number, baseColor: string, colors: string[]): void => {
    const parts = content.split('|');
    let color = false;
    let pos = 0;
    let n = 0;
    parts.forEach(part => {
        ctx.fillStyle = color ? colors[n] : baseColor;
        if (color) n = (n + 1) % colors.length;
        ctx.fillText(part, x + pos, y);
        color = !color;
        pos += ctx.measureText(part).width;
    });
};

export const doubleStroke = (ctx: CanvasRenderingContext2D, width: number = 5, color: string = '#fff', lineWidth: number = 5, lineColor: string = '#000'): void => {
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = width + 2 * lineWidth;
    ctx.stroke();
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.stroke();
};